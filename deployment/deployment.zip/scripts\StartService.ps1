$ErrorActionPreference = 'Stop'
Start-Service ASPNETCoreDemo