$ErrorActionPreference = 'Stop'
Invoke-WebRequest http://localhost:80 -UseBasicParsing